using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;

public class TestBigO : MonoBehaviour
{
    public int NumberOfElements = 1000;
    public float[] xs;
    public float[] xs_sorted;
    // Start is called before the first frame update
    void Start()
    {
        xs = new float[NumberOfElements];
        xs_sorted = new float[NumberOfElements];
        ArrayList xs_al = new ArrayList();
        //TimeSpan timeSpan = new TimeSpan(0);
        //Populate first xs
        //Populate xs_al
        Stopwatch stopwatch = new Stopwatch();
        stopwatch.Start();
        print($"Start populating: n={NumberOfElements}: " + Time.time);
        for (int i = 0; i < xs.Length; i++)
        {
            xs[i] = UnityEngine.Random.value;
            xs_al.Add(xs[i]);
        }
        long populatingMS = stopwatch.ElapsedMilliseconds;
        print($"populatingMS= {populatingMS}");


        //Then sort with ArrayList.Sort

        xs_al.Sort();
        print($"Start ArrayLsit.Sort");
        //Then measure how long it took for sorting
        long al_sortingMS = stopwatch.ElapsedMilliseconds - populatingMS;
        print($"al_sortingMS = {al_sortingMS}");


        //Sort with MySortAscending
        //should be from utilitites
        print($"Start Utilities.MySortAcsending");
        xs_sorted = Utilities.MySortAscending(xs);
        print($"End of sorting");
        long MySortAscendingMS = stopwatch.ElapsedMilliseconds - al_sortingMS;
        print($"MySortAscendingMS = {MySortAscendingMS} ");

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
